class menu:
    def __init__(self,pizza_name,ingredients,discount):
        self.pizza_name=pizza_name
        self.ingredients=ingredients
        self.discount = discount



