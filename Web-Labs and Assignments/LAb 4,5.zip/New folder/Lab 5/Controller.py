import Book 
import BorrowRecord 
import Controller
import View
import DB
from Book import*
from BorrowRecord import *
from Controller import *
from View import *
from DB import *


class Controller:
    def __init__(self):
        pass
    def addBk(self,studentObj):
        db=DB("localhost","root","jamshaid1818@18","mv_library")
        inserted=db.addBook(studentObj)
        return inserted
    def searchBk(self,inp):
        db=DB("localhost","root","jamshaid1818@18","mv_library")
        found,data=db.searchBook(inp)
        return [found,data]
    def deleteBk(self,inp):
        db=DB("localhost","root","jamshaid1818@18","mv_library")
        de=db.deleteBook(inp)
        return de
    def borrowedBook(self,inp):
        db=DB("localhost","root","jamshaid1818@18","mv_library")
        de=db.borrowBook(inp)
        return de
    def searchistory(self,inp):
        db=DB("localhost","root","jamshaid1818@18","mv_library")
        found,data=db.borrowerHistory(inp)
        return [found,data]
    
    

    
        
    
    
    
    
    
    
    

    
