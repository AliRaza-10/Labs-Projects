class Book:
    def __init__(self, title="", price=0, author="", Isbn="", total_copies=0, available_copies=0):
        # self.id = id
        self.title = title
        self.price = price
        self.author = author
        self.Isbn = Isbn
        self.total_copies = total_copies
        self.available_copies = available_copies

    def addBook(self):
        print("Add Book Info Here !!!!!")
        # id = input("Enter the Id of the book: ")
        title = input("Enter the title of the book: ")
        price = float(input("Enter the price of the book: "))
        author = input("Enter the author of the book: ")
        ISBN13 = input("Enter the ISBN13 (must include 978 or 979 as prefix): ")
        EAN=ISBN13[0:3]
        group = ISBN13[3:5]
        publisher = ISBN13[5:9]
        title_t = ISBN13[9:12]
        check_digit = ISBN13[12]


        while len(ISBN13) != 13 and (EAN != "978" or EAN != "979"):
            # print(len(ISBN13))
            # print(group)
            print("Invalid ISBN13.")
            ISBN13 = input("Again Enter the ISBN13 (must include 978 or 979 as prefix): ")
            # SPECIFYING THE MULTIPLE DATA FILDS IN ISBNP13
            if len(ISBN13) == 13:
                EAN=ISBN13[0:3]
                group = ISBN13[3:5]
                publisher = ISBN13[5:9]
                title_t = ISBN13[9:12]
                check_digit = ISBN13[12]
        t_copies=input("Enter the total Copies of the Book :")
        a_copies=input("Enter the available Copies of the Book :")

        return [title,price,author,ISBN13,t_copies,a_copies]
    
    # Function to search a new book to the database
    def searchBook(self):
       
        id = input("Enter the Id of the book: ")
        title = input("Enter the title of the book: ")
        # price = float(input("Enter the price of the book: "))
        author = input("Enter the author of the book: ")
        ISBN13 = input("Enter the ISBN13 (must include 978 or 979 as prefix): ")
        if len(ISBN13) == 13 and len(ISBN13) !=0:
            EAN=ISBN13[0:3]
            group = ISBN13[3:5]
            publisher = ISBN13[5:9]
            title_t = ISBN13[9:12]
            check_digit = ISBN13[12]
        if len(ISBN13) !=0:
            while len(ISBN13) != 13 and (EAN != "978" or EAN != "979"):
                # print(len(ISBN13))
                # print(group)
                print("Invalid ISBN13.")
                ISBN13 = input("Again Enter the ISBN13 (must include 978 or 979 as prefix): ")
                # SPECIFYING THE MULTIPLE DATA FILDS IN ISBNP13
                if len(ISBN13) == 13 and len(ISBN13) !=0:
                    EAN=ISBN13[0:3]
                    group = ISBN13[3:5]
                    publisher = ISBN13[5:9]
                    title_t = ISBN13[9:12]
                    check_digit = ISBN13[12]
        t_copies=input("Enter the total Copies of the Book :")
        a_copies=input("Enter the available Copies of the Book :")
        return [id,title,author,ISBN13,t_copies,a_copies]

    # Function to delete a book from the database
    def deleteBook(self):
        bookId = int(input("Enter the ID of the book to delete: "))
        return bookId