import Book
from Book import *
import BorrowRecord
from BorrowRecord import *
import Controller
from Controller import *

class View:
    def __init__(self):
        pass
        
    def printData(self,results,indicator):
        if indicator==0:
            print("{:<30} {:<20} {:<10} {:<20} {:<20}".format("BOOK ID","Title", "Author", "Total Copies", "available Copies"))
            for row in results: 
                    # strings = [str(row[0]),'-',row[1],'-',row[3],'-',str(row[5]),'-',str(row[6])]
                    print("{:<30} {:<20} {:<10} {:<20} {:<20}".format(str(row[0]),row[1],row[3],str(row[5]),str(row[6])))
        else:
            print("{:<10} {:<20} {:<15} {:<15} {:<10} {:<10} {:<10}".format("ID", "BOOK ID", "BORROWED BY", "BORROW DATE", "RETURN DATE", "FINE", "FINE STATUS"))
            for row in results:
                print("{:<10} {:<20} {:<15} {:<15} {:<14} {:<15} {:<20}".format(row[0], row[1], row[2], row[3].strftime('%Y-%m-%d'),row[4].strftime('%Y-%m-%d'), row[5], row[6]))

            # print("{:<30} {:<20} {:<10} {:<20} {:<20}{:<20} {:<20}".format("Id,BOOK ID","BORROWED BY", "BORROW DATE", "RETURN DATE", "FINE","FINE SATUS"))
            # for row in results:
            #         print(row) 
            #         # strings = [str(row[0]),'-',row[1],'-',row[2],'-',str(row[3]),'-',str(row[4]),'-',str(row[5]),'-',str(row[6])]
            #         print("{:<30} {:<20} {:<10} {:<20} {:<20}{:<20} {:<20}".format(str(row[0]),row[1],row[2],row[3].strftime('%Y-%m-%d'),row[4].strftime('%Y-%m-%d'),row[5],row[6]))
    
    def getMenueInput(self,choice,functio):
        print("-----------------")
        if functio==1:
            if choice==1:
                std=Book()
                print("------------")
                BookObj=std.addBook()
                con=Controller()
                inserted=con.addBk(BookObj)
                if inserted[0]:
                    self.printMSG(f"Book Successfully Added – the ID assigned is: {inserted[1]}")
                else:
                    self.printMSG("This Book already exists in the system")

            elif choice==2:
                std=Book()
                inp=std.deleteBook()
                con=Controller()
                de=con.deleteBk(inp)
                if de:
                    self.printMSG("Book Successfully deleted")
                else:
                    self.printMSG("Not exsist")
            elif choice==3:
                std=Book()
                inp=std.searchBook()
                con=Controller()
                de,data=con.searchBk(inp)
                if len(data) !=0:
                    self.printData(data,0)
        else:
            if choice==1:
                std=BorrowRecord()
                print("------------")
                BrObj=std.borrow(0)
                con=Controller()
                bor=con.borrowedBook(BrObj)
                if bor:
                    self.printMSG("Book Issued Successfully")
                elif not bor:
                    self.printMSG("This is a defaulter Person")
                else:
                    self.printMSG("This Book is not available")
            elif choice==2:
                std=BorrowRecord()
                print("------------")
                BrObj=std.borrow(-1)
                con=Controller()
                ret=con.returnedBook(BrObj)
                if ret[0]:
                    self.printMSG(f"Book Returned Successfully.Now its available copies are {ret[1]}")
                else:
                    self.printMSG("This book was not borrowed by this returner")
            elif choice==3:
                std=BorrowRecord()
                print("------------")
                inp=std.viewBorrowed()
                con=Controller()
                de,data=con.searchistory(inp)
                if de:
                    self.printData(data,1)
        
    def printMSG(self,msg):
        print(msg)