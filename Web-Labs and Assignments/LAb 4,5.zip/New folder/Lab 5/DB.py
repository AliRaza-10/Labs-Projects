import BorrowRecord
from BorrowRecord import *
import pymysql
import View
from View import *

class DB:
    def __init__(self,host,user,password,database):
        self.host=host
        self.user = user
        self.password=password
        self.database=database

    def addBook(self,student):
        v=View.View()
        mydb = None
        mydbCursor=None
        inserted = False
        results=None
        try:
            # Get DB Connection
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            # Get cursor object
            mydbCursor = mydb.cursor()

            sql1="select * from book where (isbn=%s)"
            args1=(student[3])
            mydbCursor.execute(sql1, args1)
            results = mydbCursor.fetchone()
            if results is None:    
                sql1="insert into book (title,price,author,isbn,total_copies,available_copies) values (%s,%s,%s,%s,%s,%s)"
                args1=(student[0],float(student[1]),student[2],student[3],int(student[4]),int(student[5]))
                mydbCursor.execute(sql1, args1)
                mydb.commit()   
                inserted=True
                sql1="select *from book where (isbn=%s)"
                args1=(student[3])
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchone()                
        except Exception as e:
            v.printMSG(e)
        finally:
            if mydbCursor != None:
                mydbCursor.close()

            if mydb != None:
                mydb.close()
    
            return  [inserted,results[0]]
            
    def searchBook(self,student):
        v=View.View()
        mydb = None
        mydbCursor=None
        found = False
        dataFound=[]
        try:
            # Get DB Connection
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            # Get cursor object
            mydbCursor = mydb.cursor()
            data=set()
            if(student[0]!=""):
                sql1="select * from book where (id=%s)"
                args1=(int(student[0]))
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchone()
                if results is not None:
                    data.add(results[0])
            if(student[1]!=""):
                sql1="select * from book where (title=%s)"
                args1=(student[1])
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchall()
                if results is not None:
                    for r in results:
                        data.add(r[0])
            if(student[2]!=""):
                sql1="select * from book where (author=%s)"
                args1=(student[2])
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchall()
                if results is not None:
                    for r in results:
                        data.add(r[0])
            if(student[3]!=""):
                sql1="select * from book where (isbn=%s)"
                args1=(student[3])
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchone()
                if results is not None:
                    for r in results:
                        data.add(r[0])
            if(student[4]!=""):
                sql1="select * from book where (total_copies=%s)"
                args1=(int(student[4]))
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchall()
                if results is not None:
                    for r in results:
                        data.add(r[0])
            if(student[5]!=""):
                sql1="select * from book where (available_copies=%s)"
                args1=(int(student[5]))
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchall()
                if results is not None:
                    for r in results:
                        data.add(r[0])
                
            print(data)

            for i in data:
                sql1="select * from book where (id=%s)"
                args1=(int(i))
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchone()
                dataFound.append(results)
            found=True
        except Exception as e:
            v.printMSG(e)
        finally:
            if mydbCursor != None:
                mydbCursor.close()
            if mydb != None:
                mydb.close()
    
            return  [found,dataFound]
        
    def deleteBook(self,id):
        vie=View.View()
        mydb = None
        mydbCursor=None
        deleted = False
        try:
            # Get DB Connection
            mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
            # Get cursor object
            mydbCursor = mydb.cursor()
            sql1="select * from book where id=%s"
            args1=(id)
            mydbCursor.execute(sql1, args1)
            results = mydbCursor.fetchone()
            if results is None:
                return deleted
            
            sql = "delete from book where id=%s"
            args=(id)
            mydbCursor.execute(sql, args)
            mydb.commit()
            deleted=True


        except Exception as e:
            vie.printMSG(e)
        finally:
            if mydbCursor != None:
                mydbCursor.close()

            if mydb != None:
                mydb.close()
            return  deleted

    def borrowBook(self,student):
            v=View.View()
            mydb = None
            mydbCursor=None
            found = False
            try:
                # Get DB Connection
                mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
                # Get cursor object
                mydbCursor = mydb.cursor()
                sql1="select * from borrowrecord where (borrowed_by=%s)"
                args1=(student[0])
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchall()
                if results is not None and len(results)>=3:
                    return found
                elif results is not None:
                    for r in results:
                        # check that if the status is pending or done
                        if r[6] !=0:
                            sql1="select * from book where (id=%s)"
                            args1=(int(student[1]))
                            mydbCursor.execute(sql1, args1)
                            results1 = mydbCursor.fetchone()
                            if results1 is None:
                                return None
                                            
                            sql1="update borrowrecord  set book_id=%s , borrowed_by=%s, borrowing_date=%s,returning_date=%s,fine=%s,fine_status=%s where id=%s"
                            br=BorrowRecord()
                            bDate,rDate,fine,status=br.borrow(1)
                            args1=(results1[4],student[0],bDate,rDate,fine,status,r[0])
                        
                            mydbCursor.execute(sql1, args1)
                            mydb.commit()
                            found=True
                            sql1="update book set available_copies=%s where id=%s"
                            args1=(results1[6]-1,results1[0])
                            mydbCursor.execute(sql1, args1)
                            mydb.commit()
                            # print(results1[6]-1)
                    else:
                        sql1="select * from book where (id=%s)"
                        args1=(int(student[1]))
                        mydbCursor.execute(sql1, args1)
                        results1 = mydbCursor.fetchone()
                        if results1 is None:
                            return None
                                            
                        sql1="INSERT INTO borrowrecord (book_id, borrowed_by, borrowing_date, returning_date, fine, fine_status) VALUES(%s,%s,%s,%s,%s,%s) "
                        br=BorrowRecord()
                        bDate,rDate,fine,status=br.borrow(1)
                        args1=(results1[4],student[0],bDate,rDate,fine,status)
                        
                        mydbCursor.execute(sql1, args1)
                        mydb.commit()
                        found=True
                        sql1="update book set available_copies=%s where id=%s"
                        args1=(results1[6]-1,results1[0])
                        mydbCursor.execute(sql1, args1)
                        mydb.commit()

            except Exception as e:
                v.printMSG(e)
            finally:
                if mydbCursor != None:
                    mydbCursor.close()

                if mydb != None:
                    mydb.close()
        
                return  found
        
 
    def returnBook(self,student):
            v=View.View()
            mydb = None
            mydbCursor=None
            returned = False
            copies=""
            try:
                # Get DB Connection
                mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
                # Get cursor object
                mydbCursor = mydb.cursor()
                sql1="select * from book where (id=%s)"
                args1=(student[0])
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchone()
                if results is None:
                    return None
                
                else:                        
                    sql1="select * from borrowrecord where (book_id=%s and borrowed_by=%s)"
                    args1=(results[4],student[1])
                    mydbCursor.execute(sql1, args1)
                    res=mydbCursor.fetchone()

                    if res is not None:
                        sql1="delete from borrowrecord where (id=%s)"
                        args1=(res[0])
                        mydbCursor.execute(sql1, args1)
                        mydb.commit()

                    sql1="update book set available_copies=%s where id=%s"
                    args1=(results[6]+1,results[0])
                    copies=results[6]+1
                    mydbCursor.execute(sql1, args1)
                    mydb.commit()
                    returned=True


            except Exception as e:
                v.printMSG(e)
            finally:
                if mydbCursor != None:
                    mydbCursor.close()

                if mydb != None:
                    mydb.close()
        
                return  [returned,copies]
            
    def borrowerHistory(self,id):
            v=View.View()
            mydb = None
            mydbCursor=None
            found = False
            data=""
            try:
                # Get DB Connection
                mydb = pymysql.connect(host=self.host, user=self.user, password=self.password, database=self.database)
                # Get cursor object
                mydbCursor = mydb.cursor()
                sql1="select * from borrowrecord where (borrowed_by=%s)"
                args1=(id)
                mydbCursor.execute(sql1, args1)
                results = mydbCursor.fetchall()
                if results is not None:
                    found=True

                data=results
            except Exception as e:
                v.printMSG(e)
            finally:
                if mydbCursor != None:
                    mydbCursor.close()

                if mydb != None:
                    mydb.close()
                return  [found,data]
