import datetime
class BorrowRecord:
    def __init__(self, record_id="", book_id="", borrowed_by="", borrowing_date="", returning_date=None, fine=0, fine_status=False):
        self.record_id = record_id
        self.book_id = book_id
        self.borrowed_by = borrowed_by
        self.borrowing_date = borrowing_date
        self.returning_date = returning_date
        self.fine = fine
        self.fine_status = fine_status
    def borrow(self,indicator):
            if indicator==0:
                bId=input("Enter borrower Id :")
                bkId=input("Enter The Id of the Book :")
                return [bId,bkId]
            if indicator==-1:
                bkId=input("Enter The Id of the Book to be returned :")
                bId=input("Enter the returner identity :")
                return [bkId,bId]
            else:
                bDate=datetime.date.today()
                rDate=""
                # rDate=bDate+datetime.timedelta(days=14)
                if (rDate - bDate)>datetime.timedelta(days=14):
                    fine=abs(int((14-(rDate - bDate)))*10)
                else:
                    fine=0
                status=0
                return [bDate,rDate,fine,status]
    def viewBorrowed(self):
        bId=input("Enter borrower Id :")
        return bId

                 
                 


