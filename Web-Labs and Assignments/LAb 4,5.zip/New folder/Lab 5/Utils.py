import View
from View import *
import Book 
import BorrowRecord 
from Book import*
from BorrowRecord import *
from DB import *
from Controller import *

def MainMenue(c):
        
        if c==1:
            print("1. ADD BOOK")
            print("2. DELETE BOOK")
            print("3. SEARCH BOOK")
            print("4. EXIT")
        else:
            print("1. BORROW BOOK")
            print("2. RETURN BOOK")
            print("3. VIEW BORROW BOOK")
            print("4. EXIT")
        c1=int(input("Enter your choice: "))
        return c1

def Menue():
    print("***************************************WELCOME HERE***************************************************")
    print("1. MANAGE BOOKS ")
    print("2. MANAGE BOOK BORROWINGS ")
    print("3. Exit ")
    c=int(input("Enter Your choice :"))
    return c

# --------------------------------------------------------------------------------------------
# main driven function
view=View.View()
c=Menue()
c1=MainMenue(c)
get=view.getMenueInput(c1,c)
