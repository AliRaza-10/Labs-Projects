# import Person
# import Company
# from Company import search
from  Medicine import *
from Company import *
from  Person import *

import pymysql

def Menue():
    print("1. To ADD Medicine")
    print("2. Search Company")
    print("3. Search Medicine")
    print("4. Search Medicine In Range")
    print("5. Delete Medicine")
    print("6. Delete location of company")
    choice = int(input("Enter your choice: "))
    return choice

def InsertMedicine():
    per=Person()
    company=Company()
    medicine=Medicine()

    mydb = None
    dbCursor= None
    try:

        mydb = pymysql.connect(host="localhost", user="root", password="jamshaid1818@18", database="medicinesystem")
        dbCursor=mydb.cursor()
        print("********************WELCOME*************************")
        if mydb is not None:
            print("connected")
            choice = Menue()
            if choice == 1:
                done=medicine.addMed(mydb,dbCursor)
                if done:
                    print("Medicine data Entered successfully.")
                    print()
                else:
                    print("Error")
                    print() 
            elif choice==2:
                company.searchCompany(mydb,dbCursor)
            elif choice==3:
                medicine.searchMedicine(mydb,dbCursor)
            elif choice==4:
                medicine.searchMedicineInRange(mydb,dbCursor)
            elif choice==5:
                done=medicine.deleteMedicine(mydb,dbCursor)
                if done:
                    print("Medicine Deleted successfully.")
                    print()
                else:
                    print("NOT FOUND")
                    print()
            elif choice==6:
                done1,data=company.updateLocation(mydb,dbCursor)
                done2=medicine.updateLocation(mydb,dbCursor,data)
                if done1:
                    print("Location updated successfully in company table.")
                    print()
                else:
                    print("NOT FOUND")
                    print()
                if done2:
                    print("Location updated successfully in Medicine table.")
                    print()
                else:
                    print("NOT FOUND")
                    print()



    except Exception as e:
        print(str(e))
    finally:
        if dbCursor !=None:
            dbCursor.close()

        if mydb !=None:
            mydb.close()




#  main driven
if __name__ == "__main__":
    InsertMedicine()









