import pymysql
# creating a class Medicine with attributes 

class Person:
    def __init__(self,name="",contact="",city="" ):       
        self.name = name
        self.contact = contact
        self.city = city

    def addPerson(self,connection,cursor):
        name = input("Enter Person name: ")
        contact = input("Enter Person contact :")
        city = input("Enter the Person city: ")
        query="INSERT INTO person (`name`, `contact`, `city`) VALUES (%s, %s, %s)"
        args=(name,contact,city)
        # Insert the new book into the database
        cursor.execute(query,args)
        connection.commit()
        return True,[name,contact,city]  

