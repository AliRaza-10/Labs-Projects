# import Company
from Company import *
from Person import *
class Medicine:
    def __init__(self,name="",company="",formula="",price=""):
        self.name=name
        self.company=company
        self.formula=formula
        self.price=price

    def addMed(self,connection,cursor):
        print("Add Medicine Info Here !!!!!")
        company=Company()
        per=Person()
        added,vals=per.addPerson(connection,cursor)
        if added:
            print("Person Data Added successfully")
            added,vals1=company.add(connection,cursor,vals)
            if added:
                print("Company Data Added successfully")
        
                name = input("Enter medicine name: ")
                formula = input("Enter Medicine Formula :")
                price = float(input("Enter the medicine price: "))
                
                print(name,formula,price,vals1[0],vals1[1],vals1[2],vals[0],vals[1],vals[2])
                query="INSERT INTO medicine(`name`, `formula`, `price`, `company_name`, `location`, `reg_code`, `owner_name`, `owner_contact`, `owner_city`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s,%s)"
                
                args=(name,formula,price,vals1[0],vals1[1],vals1[2],vals[0],vals[1],vals[2])
                # Insert the new book into the database
                cursor.execute(query,args)
                connection.commit()
                return True

    def searchMedicine(self,connection,cursor):
        
            name=input("Enter the Company name :")
            query="SELECT * FROM Medicine WHERE company_name LIKE %s" 
            args=(name)
            # args = (f'{EAN}', f'{group}', f'{publisher}', f'{title}', f'{check_digit}')
            cursor.execute(query,args)
        
            results = cursor.fetchall()
            if len(results) == 0:
                print("Doesn't exist.")
            else:
                # Print the results
                for row in results:
                    print("Name :",row[1])
                    print("Formula :",row[2])
                    print("Price :",row[3])

    def searchMedicineInRange(self,connection,cursor):
        
            lower=int(input("Enter the lower range prise :"))
            upper=int(input("Enter the lower range prise :"))
            query="SELECT name, formula ,price FROM Medicine WHERE price >= %s and price <= %s" 
            args=(lower,upper)
            # args = (f'{EAN}', f'{group}', f'{publisher}', f'{title}', f'{check_digit}')
            cursor.execute(query,args)
        
            results = cursor.fetchall()
            if len(results) == 0:
                print("Doesn't exist.")
            else:
                # Print the results
                for row in results:
                    print("Name :",row[0])
                    print("Formula :",row[1])
                    print("Price :",row[2])



    def deleteMedicine(self,connection,cursor):
            formula=input("Enter the Formula of the medicine :")
            query="select * FROM Medicine WHERE formula LIKE %s" 
            args=(formula)
            # args = (f'{EAN}', f'{group}', f'{publisher}', f'{title}', f'{check_digit}')
            cursor.execute(query,args)
            rec=cursor.fetchone()
            if rec!=None:
                query="Delete  FROM Medicine WHERE formula LIKE %s" 
                args=(formula)
                cursor.execute(query,args)
                connection.commit()
                return True
            else:
                return False
            
    def updateLocation(self,connection,cursor,data):
        query="SELECT * FROM Company WHERE reg_code=%s"
        args=(data[1])
        cursor.execute(query,args)
        result = cursor.fetchone()
        if result is None:
            return False
        else:
            query="UPDATE Medicine SET location=%s WHERE reg_code=%s"
            args=(data[0],data[1])
            cursor.execute(query,args)
            connection.commit()
            return True