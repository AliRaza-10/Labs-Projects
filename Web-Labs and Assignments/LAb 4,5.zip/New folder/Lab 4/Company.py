from Person import *  
class Company:
    def __init__(self,name="",location="",owner="",regestration_code=""):
        self.name=name
        self.location=location
        self.owner=owner
        self.regestration_code=regestration_code

    def add(self,connection,cursor,person):

        name = input("Enter Company name: ")
        location = input("Enter Company location :")
        reg = input("Enter the Company reg_code: ")
        
        query="INSERT INTO company (`name`, `location`, `reg_code`,`owner_name`, `owner_contact`, `owner_city`) VALUES (%s, %s, %s,%s,%s,%s)"
        args=(name,location,reg,person[0],person[1],person[2])
        # Insert the new book into the database
        cursor.execute(query,args)
        connection.commit()
        return True,[name,location,reg]
    
    def searchCompany(self,connection,cursor):
    
        name=input("Enter the owner name :")
        query="SELECT * FROM Company WHERE owner_name LIKE %s" 
        args=(name)
        # args = (f'{EAN}', f'{group}', f'{publisher}', f'{title}', f'{check_digit}')
        cursor.execute(query,args)
    
        results = cursor.fetchall()
        if len(results) == 0:
            print("Doesn't exist.")
        else:
            # Print the results
            for r in results:
                print("Name :",r[0])
                print("Location :",r[1])

    def updateLocation(self,connection,cursor):
        reg = input("Enter the Regestration code of the company to update: ")
        query="SELECT * FROM Company WHERE reg_code=%s"
        args=(reg)
        cursor.execute(query,reg)
        result = cursor.fetchone()
        if result is None:
            return False
        else:
            location = input("Enter the new location of company: ")
    
            query="UPDATE Company SET location=%s WHERE reg_code=%s"
            args=(location,reg)
            cursor.execute(query,args)
            connection.commit()
            return True,[location,reg]