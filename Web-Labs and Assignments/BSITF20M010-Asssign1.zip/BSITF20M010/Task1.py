print("1 Add student")
print("2 Update/edit student")
print("3 Delete student")
print("4 Search Student")
print("5 Display/Print all students")
print("6 Exit")
StudentRecord = [
    {"id": 1, "name": "Ali", "rollno": "BSITF20M010", "semester": 6, "cgpa": 3.5},
    {"id": 2, "name": "Faraz", "rollno": "BSITF20M002", "semester": 3, "cgpa": 3.1}
    ]
NewStudent = {
    "id": 3,
    "name": "Ahmad",
    "rollno": "BSITF20M003",
    "semester": 8,
    "cgpa": 3.8
}
UpdatedStudent = {
    "id": 1,
    "name": "ALI RAZA",
    "rollno": "BITF20M004",
    "semester": 6,
    "cgpa": 4.0
}

def display(StudentRecord):
    count = 1
    for x in StudentRecord:
        print(f"The info of Student {count} is \n"
            " id:", x["id"] ,"\n",
            "name :", x["name"],"\n",
            "rollno :",  x["rollno"],"\n"
            " semester :",  x["semester"],"\n"
            " cgpa :",  x["cgpa"],"\n"
            )
        count = count + 1
def AddStudent(StudentRecord, NewStudent):
    StudentRecord.append(NewStudent)
def DeleteStudent(StudentRecord, Stud_id):
    for y in StudentRecord:
        if y["id"]==Stud_id:
            StudentRecord.remove(y)
            print(f"Record of Student id {Stud_id} has deleted")
    return StudentRecord
def CheckStudentExist(StudentRecord, Stud_id):
    count = 1
    for y in StudentRecord:
        if y["id"] == Stud_id:
            print(f"Student with ID {Stud_id} exists in the record.")
    if y["id"]!=Stud_id:
        print(f"No student with ID {Stud_id} found in the record.")
def UpdateStudentRecord(StudentRecord, UpdatedStudent):
    count = 0
    while(count!=UpdatedStudent["id"]):
        count+=1
    count = count -1
    StudentRecord[count] = UpdatedStudent
    print(f"Student record updated successfully for ID {UpdatedStudent['id']}.")
    return StudentRecord


flag = True
while (flag):
    choice = int(input("Enter your Choice (1-5) "))
    if(choice==1):
        print("New Record Has been Added")
        AddStudent(StudentRecord, NewStudent)
    elif(choice==2):
        StudentRecord = UpdateStudentRecord(StudentRecord, UpdatedStudent)
    elif(choice==3):
        StudentRecord = DeleteStudent(StudentRecord, 2)
    elif(choice==4):
        CheckStudentExist(StudentRecord,2)
    elif(choice==5):
        display(StudentRecord)
    elif(choice>5 or choice<1):
        print("Exit")
        flag = False
