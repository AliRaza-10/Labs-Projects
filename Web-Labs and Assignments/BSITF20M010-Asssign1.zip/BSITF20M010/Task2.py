def createPascalTriangle(rows):
    list = []
    for i in range(rows):
        row = [1] * (i+1)
        for j in range(1, i):
            row[j] = list[i-1][j-1] + list[i-1][j]
        list.append(row)
    return list
def printPascalTriangle(list):
    for row in list:
        for value in row:
            print(value,end=" ")
        print(" ")
r = int(input("Enter number of rows: "))
I = createPascalTriangle(r)
printPascalTriangle(I)