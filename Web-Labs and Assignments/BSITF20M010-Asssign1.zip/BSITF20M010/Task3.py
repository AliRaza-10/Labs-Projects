
def gameEnd(table,symbol1,symbol2):
    for i in range(3):
        if (table[i][0] == table[i][1] and table[i][0] == table[i][2]) or (table[0][i] == table[1][i] and table[0][i] == table[2][i]):
            return False
    if (table[0][0] == table[1][1] and table[0][0] == table[2][2]) or (table[0][2] == table[1][1] and table[0][2] == table[2][0]):
        return False
    
    return True

def gameTied(table,symbol1,symbol2):
    for i in range(3):
        for j in range(3):
            if table[i][j] != symbol1 and table[i][j] != symbol2:
                return False
    return True

def display(table, name1, name2,symbol1,symbol2):
    print("-------------------------T I C   T A C   T O E ---------------\n")
    print(f"\t\t{name1} {symbol1}  vs {name2} {symbol2} \n\n")
    print(f"\t {table[0][0]}   |   {table[0][1]}   |   {table[0][2]}   ")
    print("\t--------------")
    print(f"\t {table[1][0]}   |   {table[1][1]}   |   {table[1][2]}   ")
    print("\t--------------")
    print(f"\t {table[2][0]}   |   {table[2][1]}   |   {table[2][2]}   \n\n")

def spin(turn, table, name1, name2,symbol1,symbol2):
    if turn == symbol1:
        print(f"\t{name1}  your turn : ")
    else:
        print(f"\t{name2}  Now its your turn : ")
    choice = int(input())
    while choice < 1 or choice > 9:
        print("ERROR!! INVALID INPUT! TRY AGAIN ")
        choice = int(input())
    row = (choice - 1) // 3
    col = (choice - 1) % 3

    if table[row][col] not in [symbol1, symbol2]:
        table[row][col] = symbol1 if turn == symbol2 else symbol2
        turn = symbol2 if turn == symbol1 else symbol1
    else:
        print("hahaha!!! Table Filled Try Again!")
        spin(turn, table, name1, name2,symbol1,symbol2)

    return turn

def tic_tac_toe():
    table = [['1', '2', '3'], ['4', '5', '6'], ['7', '8', '9']]
    name1 = input("Enter name of Player 1  ")
    name2 = input("Enter name of Player 2  ")
    symbol2 = input("Please enter an alphabet from Aa to Zz for Player 1 : ")
    while len(symbol2) != 1 or symbol2.isdigit():
        symbol2 = input("Error!!!Please enter an alphabet from Aa to Zz: ")
    print("You entered the alphabet:",symbol2, "for ",name1)
    symbol1 = input("Please enter an alphabet from Aa to Zz for Player 2 : ")
    while len(symbol1) != 1 or symbol1.isdigit():
        symbol1 = input("Error!!!Please enter an alphabet from Aa to Zz: ")
    print("You entered the alphabet:",symbol1, "for ",name2)
    turn = symbol1
    tie = False
    while not gameTied(table,symbol1,symbol2) and gameEnd(table,symbol1,symbol2):
        display(table, name1, name2,symbol1,symbol2)
        turn=spin(turn, table, name1, name2,symbol1,symbol2)
    display(table, name1, name2,symbol1,symbol2)
    if not gameEnd(table,symbol1,symbol2):
        if  turn == symbol1:
            print(f"\t{name2}  Wins!!")
        else:
            print(f"\t{name1}  Wins!!")    
    else:
        print("Game tied")
        
tic_tac_toe()